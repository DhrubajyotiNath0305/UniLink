"use client";

import { useEffect, useState } from "react";
import {
  Search as SearchIcon,
  Users,
  CalendarDays,
} from "lucide-react";
import { useRouter } from "next/navigation";

import BottomNav from "@/components/BottomNav";
import LoginPrompt from "@/components/LoginPrompt";

import { useAuth } from "@/context/AuthContext";

import {
  getOpportunities,
} from "@/utils/opportunityStorage";

import {
  getConnectionStatus,
  sendConnectionRequest,
} from "@/utils/connectionStorage";

export default function SearchPage() {
  const router = useRouter();
  const {
    user,
    isLoggedIn,
  } = useAuth();

  const [activeTab, setActiveTab] =
    useState("people");

  const [searchQuery, setSearchQuery] =
    useState("");

  const [accounts, setAccounts] =
    useState([]);

  const [opportunities, setOpportunities] =
    useState([]);

  const [
    connectionStatuses,
    setConnectionStatuses,
  ] = useState({});

  const [
    showLoginPrompt,
    setShowLoginPrompt,
  ] = useState(false);

  useEffect(() => {
    if (
      typeof window ===
      "undefined"
    ) {
      return;
    }

    try {
      const savedAccounts =
        JSON.parse(
          localStorage.getItem(
            "unilink_accounts"
          )
        ) || [];

      setAccounts(
        Array.isArray(savedAccounts)
          ? savedAccounts
          : []
      );
    } catch {
      setAccounts([]);
    }

    try {
      const savedOpportunities =
        getOpportunities() || [];

      setOpportunities(
        Array.isArray(
          savedOpportunities
        )
          ? savedOpportunities
          : []
      );
    } catch {
      setOpportunities([]);
    }
  }, []);

  const refreshConnectionStatuses =
    () => {
      if (
        !user ||
        accounts.length === 0
      ) {
        setConnectionStatuses({});
        return;
      }

      const statuses = {};

      accounts.forEach(
        (account) => {
          if (
            String(account.id) ===
            String(user.id)
          ) {
            return;
          }

          statuses[account.id] =
            getConnectionStatus(
              user.id,
              account.id
            );
        }
      );

      setConnectionStatuses(
        statuses
      );
    };

  useEffect(() => {
    refreshConnectionStatuses();
  }, [user, accounts]);

  // Keep Search synchronized when a request is
  // sent/accepted/rejected somewhere else.
  useEffect(() => {
    if (!user) return;

    const handleConnectionUpdate =
      () => {
        refreshConnectionStatuses();
      };

    window.addEventListener(
      "unilink-connections-updated",
      handleConnectionUpdate
    );

    window.addEventListener(
      "focus",
      handleConnectionUpdate
    );

    return () => {
      window.removeEventListener(
        "unilink-connections-updated",
        handleConnectionUpdate
      );

      window.removeEventListener(
        "focus",
        handleConnectionUpdate
      );
    };
  }, [user, accounts]);

  const query =
    searchQuery
      .trim()
      .toLowerCase();

  const otherAccounts =
    accounts.filter(
      (account) =>
        String(account.id) !==
        String(user?.id)
    );

  const filteredAccounts =
    otherAccounts.filter(
      (account) => {
        const skills =
          Array.isArray(
            account.skills
          )
            ? account.skills.join(
                " "
              )
            : account.skills || "";

        const searchableText = `
          ${account.name || ""}
          ${account.username || ""}
          ${account.email || ""}
          ${account.department || ""}
          ${account.branch || ""}
          ${account.course || ""}
          ${account.year || ""}
          ${account.studyYear || ""}
          ${account.graduationYear || ""}
          ${account.currentJob || ""}
          ${account.currentRole || ""}
          ${account.company || ""}
          ${skills}
          ${account.bio || ""}
          ${account.accountType || ""}
        `.toLowerCase();

        return searchableText.includes(
          query
        );
      }
    );

  const filteredOpportunities =
    opportunities.filter(
      (opportunity) => {
        const searchableText = `
          ${opportunity.title || ""}
          ${opportunity.type || ""}
          ${opportunity.location || ""}
          ${opportunity.description || ""}
        `.toLowerCase();

        return searchableText.includes(
          query
        );
      }
    );

  const getProfileImage = (
    account
  ) => {
    if (account.profilePhoto) {
      return account.profilePhoto;
    }

    if (account.avatar) {
      return account.avatar;
    }

    return `https://i.pravatar.cc/100?u=${
      account.id ||
      account.email ||
      account.name
    }`;
  };

  const getBranch = (
    account
  ) => {
    return (
      account.branch ||
      account.department ||
      account.course ||
      "Student"
    );
  };

  const getYear = (
    account
  ) => {
    return (
      account.year ||
      account.studyYear ||
      ""
    );
  };

  const handleConnect = (
    accountId
  ) => {
    if (
      !isLoggedIn ||
      !user
    ) {
      setShowLoginPrompt(true);
      return;
    }

    if (
      String(user.id) ===
      String(accountId)
    ) {
      return;
    }

    const status =
      getConnectionStatus(
        user.id,
        accountId
      );

    if (status !== "none") {
      setConnectionStatuses(
        (previous) => ({
          ...previous,
          [accountId]: status,
        })
      );

      return;
    }

    const connection =
      sendConnectionRequest(
        user.id,
        accountId
      );

    if (connection) {
      setConnectionStatuses(
        (previous) => ({
          ...previous,
          [accountId]:
            connection.status ||
            "pending",
        })
      );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24 lg:pb-10">

      {/* Header */}

      <header
        className="
          sticky
          top-0
          z-40
          border-b
          border-slate-200
          bg-white/95
          px-4
          py-4
          backdrop-blur-md
          lg:ml-[225px]
        "
      >
        <div className="mx-auto max-w-4xl">
          <div className="flex items-center gap-3">
            <SearchIcon
              size={20}
              className="text-slate-400"
            />

            <input
              value={searchQuery}
              onChange={(event) =>
                setSearchQuery(
                  event.target.value
                )
              }
              placeholder="Search people, opportunities..."
              className="w-full bg-transparent text-sm text-slate-800 outline-none placeholder:text-slate-400"
            />
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-4xl px-4 py-6 sm:px-6 lg:ml-[225px] lg:px-8">

        <div className="flex gap-2 rounded-xl bg-white p-1 shadow-sm ring-1 ring-slate-200">
          <button
            type="button"
            onClick={() =>
              setActiveTab("people")
            }
            className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-xs font-semibold ${
              activeTab === "people"
                ? "bg-indigo-500 text-white"
                : "text-slate-500 hover:bg-slate-50"
            }`}
          >
            <Users size={15} />
            People
          </button>

          <button
            type="button"
            onClick={() =>
              setActiveTab(
                "opportunities"
              )
            }
            className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-xs font-semibold ${
              activeTab ===
              "opportunities"
                ? "bg-indigo-500 text-white"
                : "text-slate-500 hover:bg-slate-50"
            }`}
          >
            <CalendarDays
              size={15}
            />
            Opportunities
          </button>
        </div>

        {activeTab ===
          "people" && (
          <section className="mt-5 space-y-3">

            {filteredAccounts.map(
              (account) => {
                const status =
                  connectionStatuses[
                    account.id
                  ] || "none";

                return (
                  <article
                    key={account.id}
                    className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
                  >
                    <div className="flex items-center gap-3">

                      <button
                        type="button"
                        onClick={() =>
                          router.push(
                            `/profile/${account.id}`
                          )
                        }
                        className="flex min-w-0 flex-1 items-center gap-3 text-left"
                      >
                        <img
                          src={getProfileImage(
                            account
                          )}
                          alt={
                            account.name ||
                            "User"
                          }
                          className="h-12 w-12 shrink-0 rounded-full object-cover"
                        />

                        <div className="min-w-0">
                          <h3 className="truncate text-sm font-semibold text-slate-900">
                            {account.name ||
                              "Student"}
                          </h3>

                          <p className="mt-1 truncate text-xs text-slate-500">
                            {getBranch(
                              account
                            )}

                            {getYear(
                              account
                            ) &&
                              ` • ${getYear(
                                account
                              )}`}
                          </p>

                          {Array.isArray(
                            account.skills
                          ) &&
                            account.skills
                              .length >
                              0 && (
                              <p className="mt-1 truncate text-xs text-slate-400">
                                {account.skills
                                  .slice(
                                    0,
                                    3
                                  )
                                  .join(
                                    " • "
                                  )}
                              </p>
                            )}
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          handleConnect(
                            account.id
                          )
                        }
                        disabled={
                          status !==
                          "none"
                        }
                        className={`
                          shrink-0
                          rounded-xl
                          px-3
                          py-2
                          text-xs
                          font-semibold
                          transition

                          ${
                            status ===
                            "pending"
                              ? "bg-slate-100 text-slate-500"
                              : status ===
                                "accepted"
                              ? "bg-green-50 text-green-600"
                              : "bg-indigo-600 text-white hover:bg-indigo-700"
                          }
                        `}
                      >
                        {status ===
                        "pending"
                          ? "Pending"
                          : status ===
                            "accepted"
                          ? "Connected"
                          : "Connect"}
                      </button>

                    </div>
                  </article>
                );
              }
            )}

          </section>
        )}

        {activeTab ===
          "opportunities" && (
          <section className="mt-5 space-y-3">
            {filteredOpportunities.map(
              (opportunity) => (
                <button
                  key={
                    opportunity.id
                  }
                  type="button"
                  onClick={() =>
                    router.push(
                      `/create/opportunity/${opportunity.id}`
                    )
                  }
                  className="w-full rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm hover:bg-slate-50"
                >
                  <h3 className="text-sm font-semibold text-slate-900">
                    {
                      opportunity.title
                    }
                  </h3>

                  <p className="mt-1 text-xs text-slate-500">
                    {
                      opportunity.location
                    }
                  </p>

                  <p className="mt-2 text-xs leading-5 text-slate-500">
                    {
                      opportunity.description
                    }
                  </p>
                </button>
              )
            )}
          </section>
        )}

      </main>

      <BottomNav />

      <LoginPrompt
        isOpen={
          showLoginPrompt
        }
        onClose={() =>
          setShowLoginPrompt(false)
        }
      />
    </div>
  );
}