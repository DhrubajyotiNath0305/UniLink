"use client";

import { useEffect, useState } from "react";
import {
  ArrowLeft,
  MessageCircle,
  Search,
} from "lucide-react";
import { useRouter } from "next/navigation";

import BottomNav from "@/components/BottomNav";
import LoginPrompt from "@/components/LoginPrompt";
import { useAuth } from "@/context/AuthContext";

import {
  getConversationUserIds,
  getLatestMessage,
  getUnreadFromUser,
} from "@/utils/messageStorage";

export default function MessagesPage() {
  const router = useRouter();
  const { user, isLoggedIn, loading } = useAuth();

  const [accounts, setAccounts] = useState([]);
  const [conversations, setConversations] = useState([]);
  const [search, setSearch] = useState("");
  const [showLoginPrompt, setShowLoginPrompt] =
    useState(false);

  const loadConversations = () => {
    if (!user) return;

    const savedAccounts =
      JSON.parse(
        localStorage.getItem("unilink_accounts")
      ) || [];

    setAccounts(savedAccounts);

    const userIds = getConversationUserIds(user.id);

    const data = userIds
      .map((userId) => {
        const account = savedAccounts.find(
          (item) =>
            String(item.id) === String(userId)
        );

        if (!account) return null;

        const latestMessage =
          getLatestMessage(user.id, userId);

        const unreadCount = getUnreadFromUser(
          user.id,
          userId
        );

        return {
          account,
          latestMessage,
          unreadCount,
        };
      })
      .filter(Boolean)
      .sort((a, b) => {
        const timeA = Number(
          a.latestMessage?.createdAt || 0
        );

        const timeB = Number(
          b.latestMessage?.createdAt || 0
        );

        return timeB - timeA;
      });

    setConversations(data);
  };

  useEffect(() => {
    if (!user) return;

    loadConversations();

    const handleStorage = () => {
      loadConversations();
    };

    window.addEventListener(
      "storage",
      handleStorage
    );

    return () => {
      window.removeEventListener(
        "storage",
        handleStorage
      );
    };
  }, [user]);

  const formatTime = (timestamp) => {
    if (!timestamp) return "";

    const date = new Date(Number(timestamp));

    const now = new Date();

    const sameDay =
      date.toDateString() === now.toDateString();

    if (sameDay) {
      return date.toLocaleTimeString([], {
        hour: "numeric",
        minute: "2-digit",
      });
    }

    return date.toLocaleDateString([], {
      day: "numeric",
      month: "short",
    });
  };

  const filteredConversations =
    conversations.filter(({ account }) => {
      const query = search
        .trim()
        .toLowerCase();

      if (!query) return true;

      return (
        account.name
          ?.toLowerCase()
          .includes(query) ||
        account.username
          ?.toLowerCase()
          .includes(query) ||
        account.department
          ?.toLowerCase()
          .includes(query)
      );
    });

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <main className="flex min-h-screen items-center justify-center px-6">
          <p className="text-sm text-slate-500">
            Loading conversations...
          </p>
        </main>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <>
        <div className="min-h-screen bg-slate-50">
          <main className="flex min-h-screen items-center justify-center px-6">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-indigo-50 text-indigo-500">
                <MessageCircle size={28} />
              </div>

              <h1 className="mt-5 text-xl font-semibold text-slate-900">
                Login required
              </h1>

              <p className="mt-2 text-sm text-slate-500">
                Log in to view your messages.
              </p>

              <button
                onClick={() =>
                  setShowLoginPrompt(true)
                }
                className="mt-6 rounded-xl bg-indigo-500 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-600"
              >
                Log In
              </button>
            </div>
          </main>
        </div>

        <LoginPrompt
          isOpen={showLoginPrompt}
          onClose={() =>
            setShowLoginPrompt(false)
          }
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24 lg:ml-[220px] lg:pb-10">
      <main className="mx-auto w-full max-w-3xl px-4 pb-20 pt-6 sm:px-6 lg:px-8 lg:pt-10">

        {/* Header */}
        <header className="flex items-center gap-4">
          <button
            onClick={() => router.back()}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 transition hover:bg-slate-100"
          >
            <ArrowLeft size={19} />
          </button>

          <div>
            <h1 className="text-2xl font-semibold text-slate-900">
              Messages
            </h1>

            <p className="mt-1 text-sm text-slate-500">
              Your conversations
            </p>
          </div>
        </header>

        {/* Search */}
        <div className="relative mt-6">
          <Search
            size={18}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
          />

          <input
            type="text"
            value={search}
            onChange={(event) =>
              setSearch(event.target.value)
            }
            placeholder="Search conversations..."
            className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-11 pr-4 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100"
          />
        </div>

        {/* Conversations */}
        <section className="mt-5">
          {filteredConversations.length === 0 ? (
            <div className="flex min-h-[320px] flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white px-6 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-400">
                <MessageCircle size={28} />
              </div>

              <h2 className="mt-5 text-base font-semibold text-slate-900">
                {search
                  ? "No conversations found"
                  : "No messages yet"}
              </h2>

              <p className="mt-2 max-w-sm text-sm leading-5 text-slate-500">
                {search
                  ? "Try searching for another person."
                  : "Start a conversation with one of your connections."}
              </p>

              {!search && (
                <button
                  onClick={() =>
                    router.push("/search")
                  }
                  className="mt-5 rounded-xl bg-indigo-500 px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-indigo-600"
                >
                  Find People
                </button>
              )}
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
              {filteredConversations.map(
                ({
                  account,
                  latestMessage,
                  unreadCount,
                }) => {
                  const photo =
                    account.profilePhoto ||
                    account.avatar;

                  const lastMessage =
                    latestMessage?.text ||
                    "Start a conversation";

                  return (
                    <button
                      key={account.id}
                      type="button"
                      onClick={() =>
                        router.push(
                          `/messages/${account.id}`
                        )
                      }
                      className="flex w-full items-center gap-3 border-b border-slate-100 p-4 text-left transition last:border-b-0 hover:bg-slate-50"
                    >
                      {/* Avatar */}
                      {photo ? (
                        <img
                          src={photo}
                          alt={account.name || "User"}
                          className="h-12 w-12 shrink-0 rounded-full object-cover"
                        />
                      ) : (
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-indigo-50 text-lg font-bold text-indigo-500">
                          {account.name
                            ?.charAt(0)
                            ?.toUpperCase() ||
                            "U"}
                        </div>
                      )}

                      {/* Content */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-3">
                          <h3
                            className={`truncate text-sm ${
                              unreadCount > 0
                                ? "font-bold text-slate-900"
                                : "font-semibold text-slate-800"
                            }`}
                          >
                            {account.name ||
                              "Student"}
                          </h3>

                          <span className="shrink-0 text-[10px] text-slate-400">
                            {formatTime(
                              latestMessage?.createdAt
                            )}
                          </span>
                        </div>

                        <div className="mt-1 flex items-center justify-between gap-3">
                          <p
                            className={`truncate text-xs ${
                              unreadCount > 0
                                ? "font-semibold text-slate-700"
                                : "text-slate-500"
                            }`}
                          >
                            {lastMessage}
                          </p>

                          {unreadCount > 0 && (
                            <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-indigo-500 px-1.5 text-[9px] font-bold text-white">
                              {unreadCount > 9
                                ? "9+"
                                : unreadCount}
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                }
              )}
            </div>
          )}
        </section>
      </main>

      <BottomNav />
    </div>
  );
}