"use client";

import { useState } from "react";
import {
  ArrowLeft,
  Save,
  Code2,
  ExternalLink,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useAuth } from "../../../../context/AuthContext";
import { saveProject } from "../../../../utils/projectStorage";

export default function AddProject() {
  const router = useRouter();
  const { user } = useAuth();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [technologies, setTechnologies] = useState("");
  const [github, setGithub] = useState("");
  const [demo, setDemo] = useState("");

  if (!user) {
    return null;
  }

  const handleSubmit = (event) => {
    event.preventDefault();

    const project = {
      id: Date.now(),
      userId: user.id,
      name: name.trim(),
      description: description.trim(),

      technologies: technologies
        .split(",")
        .map((technology) => technology.trim())
        .filter((technology) => technology.length > 0),

      github: github.trim(),
      demo: demo.trim(),
    };

    saveProject(project);

    router.push("/profile");
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-[30px] md:mx-auto md:max-w-[760px] lg:max-w-[800px]">
      <header className="sticky top-0 z-50 flex h-[60px] items-center justify-between border-b border-slate-200 bg-white/95 px-4">
        <button
          className="flex items-center justify-center"
          onClick={() => router.push("/profile")}
        >
          <ArrowLeft size={21} />
        </button>

        <h2 className="text-[15px]">Add Project</h2>

        <div style={{ width: "34px" }}></div>
      </header>

      <main className="px-4 pt-[18px]">
        <form
          className="flex flex-col gap-[14px]"
          onSubmit={handleSubmit}
        >
          {/* Project Information */}
          <section className="rounded-2xl border border-slate-200 bg-white p-[17px]">
            <h2 className="mb-[15px] text-sm">Project Information</h2>

            <div className="relative mb-[14px] last:mb-0">
              <label className="mb-[7px] flex items-center gap-[5px] font-semibold text-slate-900 text-[11px]">
                Project Name
              </label>

              <input
                className="w-full max-w-full rounded-[10px] border border-slate-200 bg-slate-50 p-3 outline-none placeholder:text-slate-400 focus:border-indigo-500 focus:shadow-[0_0_0_3px_rgba(99,102,241,0.1)] text-slate-900 text-[11px]"
                type="text"
                value={name}
                onChange={(event) =>
                  setName(event.target.value)
                }
                placeholder="e.g. Campus Connect"
                required
              />
            </div>

            <div className="relative mb-[14px] last:mb-0">
              <label className="mb-[7px] flex items-center gap-[5px] font-semibold text-slate-900 text-[11px]">
                Description
              </label>

              <textarea
                className="min-h-[110px] w-full max-w-full resize-y rounded-[10px] border border-slate-200 bg-slate-50 p-3 outline-none placeholder:text-slate-400 focus:border-indigo-500 focus:shadow-[0_0_0_3px_rgba(99,102,241,0.1)] text-slate-900 text-[11px]"
                value={description}
                onChange={(event) =>
                  setDescription(event.target.value)
                }
                placeholder="What did you build? What problem does it solve?"
                maxLength={500}
                required
              />

              <span className="mt-1 block text-right text-slate-400 text-[9px]">
                {description.length}/500
              </span>
            </div>
          </section>

          {/* Technologies */}
          <section className="rounded-2xl border border-slate-200 bg-white p-[17px]">
            <h2 className="mb-[15px] text-sm">Technologies</h2>

            <div className="relative mb-[14px] last:mb-0">
              <label className="mb-[7px] flex items-center gap-[5px] font-semibold text-slate-900 text-[11px]">
                <Code2 size={15} />
                Tech Stack
              </label>

              <input
                className="w-full max-w-full rounded-[10px] border border-slate-200 bg-slate-50 p-3 outline-none placeholder:text-slate-400 focus:border-indigo-500 focus:shadow-[0_0_0_3px_rgba(99,102,241,0.1)] text-slate-900 text-[11px]"
                type="text"
                value={technologies}
                onChange={(event) =>
                  setTechnologies(event.target.value)
                }
                placeholder="React, Node.js, MongoDB"
                required
              />

              <span className="mt-[5px] block text-slate-400 text-[9px]">
                Separate technologies with commas.
              </span>
            </div>
          </section>

          {/* Links */}
          <section className="rounded-2xl border border-slate-200 bg-white p-[17px]">
            <h2 className="mb-[15px] text-sm">Project Links</h2>

            <div className="relative mb-[14px] last:mb-0">
              <label className="mb-[7px] flex items-center gap-[5px] font-semibold text-slate-900 text-[11px]">
                <Code2 size={15} />
                GitHub Repository
              </label>

              <input
                className="w-full max-w-full rounded-[10px] border border-slate-200 bg-slate-50 p-3 outline-none placeholder:text-slate-400 focus:border-indigo-500 focus:shadow-[0_0_0_3px_rgba(99,102,241,0.1)] text-slate-900 text-[11px]"
                type="url"
                value={github}
                onChange={(event) =>
                  setGithub(event.target.value)
                }
                placeholder="https://github.com/username/project"
              />
            </div>

            <div className="relative mb-[14px] last:mb-0">
              <label className="mb-[7px] flex items-center gap-[5px] font-semibold text-slate-900 text-[11px]">
                <ExternalLink size={15} />
                Live Demo
              </label>

              <input
                className="w-full max-w-full rounded-[10px] border border-slate-200 bg-slate-50 p-3 outline-none placeholder:text-slate-400 focus:border-indigo-500 focus:shadow-[0_0_0_3px_rgba(99,102,241,0.1)] text-slate-900 text-[11px]"
                type="url"
                value={demo}
                onChange={(event) =>
                  setDemo(event.target.value)
                }
                placeholder="https://your-project.com"
              />
            </div>
          </section>

          <button
            type="submit"
            className="flex w-full items-center justify-center gap-[7px] rounded-[11px] bg-indigo-500 p-3 font-semibold text-[11px] text-white active:scale-[0.98]"
          >
            <Save size={17} />
            Add Project
          </button>
        </form>
      </main>
    </div>
  );
}