"use client";

import { useEffect, useState } from "react";
import { Search as SearchIcon } from "lucide-react";

import Navbar from "@/components/Navbar";
import PostCard from "@/components/PostCard";
import BottomNav from "@/components/BottomNav";

import { getPosts } from "@/utils/postStorage";
import { useAuth } from "@/context/AuthContext";

export default function Home() {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const savedPosts = getPosts();
    setPosts(savedPosts);
  }, []);

  // Resolve the logged-in user's real profile image.
  const getUserAvatar = () => {
    return (
      user?.profilePhoto ||
      user?.avatar ||
      user?.profilePicture ||
      ""
    );
  };

  const currentUserAvatar = getUserAvatar();

  return (
    <div className="w-full min-h-screen pb-20 md:max-w-[900px] md:mx-auto lg:ml-[220px] lg:w-[calc(100%-220px)] lg:max-w-none lg:pb-10 min-[1400px]:ml-[240px] min-[1400px]:w-[calc(100%-240px)]">
      <Navbar />

      <main className="w-full bg-slate-50 pb-[10px] md:max-w-[700px] md:mx-auto lg:mx-auto lg:max-w-[720px] lg:px-5 lg:pt-[16px] lg:pb-10">

        {/* DESKTOP SEARCH */}
        <div className="hidden h-11 w-full items-center gap-[10px] rounded-[13px] border border-slate-200 bg-white px-[14px] text-slate-500 mb-[18px] lg:flex">
          <SearchIcon size={19} />

          <input
            className="w-full border-none bg-transparent text-slate-900 text-[12px] outline-none placeholder:text-slate-400"
            type="text"
            placeholder="Search posts, people, opportunities..."
          />
        </div>

        {/* STORIES
            Story feature is not implemented yet,
            so dummy story accounts are intentionally hidden.
        */}

        {/* USER POSTS */}
        {posts.map((post) => {
          const postName = post.name || post.authorName || "";

          /*
           * Existing posts may have been created with old dummy
           * avatar data. For the currently logged-in user's post,
           * always prefer the actual logged-in user's profile image.
           *
           * We check several possible ID fields because the project
           * has evolved and older post data may use different names.
           */
          const postAuthorId =
            post.userId ??
            post.authorId ??
            post.createdBy ??
            post.ownerId;

          const currentUserId = user?.id;

          const isCurrentUser =
            currentUserId != null &&
            postAuthorId != null &&
            String(postAuthorId) === String(currentUserId);

          /*
           * Older posts may not contain an author ID.
           * If the saved post was created as "You", treat it as
           * the current user's post.
           */
          const isLegacyCurrentUserPost =
            postAuthorId == null &&
            (postName === "You" ||
              postName === user?.name);

          const avatar =
            isCurrentUser || isLegacyCurrentUserPost
              ? currentUserAvatar || post.avatar
              : post.avatar;

          return (
            <PostCard
              key={post.id}
              name={post.name}
              branch={post.branch || post.department}
              year={post.year}
              time={post.time}
              content={post.content}
              likes={post.likes}
              comments={post.comments}
              image={post.image}
              avatar={avatar}
            />
          );
        })}

        {/* DEMO POSTS */}
        <PostCard
          name="Rohan Mehta"
          branch="CSE"
          year="3rd Year"
          time="2h"
          content="Just finished building a campus marketplace with an amazing team! 🚀 Grateful for this journey and everyone who supported 💙"
          likes={124}
          comments={18}
          image="https://images.unsplash.com/photo-1498050108023-c5249f4df085"
          avatar="https://i.pravatar.cc/100?img=11"
        />

        <PostCard
          name="Ananya Sharma"
          branch="ECE"
          year="2nd Year"
          time="4h"
          content="Our team just made it to the final round of the college hackathon! 🔥"
          likes={86}
          comments={12}
          image="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4"
          avatar="https://i.pravatar.cc/100?img=47"
        />

      </main>

      <BottomNav />
    </div>
  );
}