"use client";

import { useEffect, useState } from "react";
import {
  ArrowLeft,
  CalendarDays,
  MapPin,
  ExternalLink,
} from "lucide-react";
import { useRouter, useParams } from "next/navigation";

import { getOpportunities } from "@/utils/opportunityStorage";

export default function OpportunityDetails() {
  const router = useRouter();
  const params = useParams();

  const [opportunity, setOpportunity] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const opportunities = getOpportunities();

    const foundOpportunity = opportunities.find(
      (item) => String(item.id) === String(params.id)
    );

    setOpportunity(foundOpportunity || null);
    setLoading(false);
  }, [params.id]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <p className="text-sm text-slate-500">
          Loading opportunity...
        </p>
      </div>
    );
  }

  if (!opportunity) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-slate-50 px-4">
        <h2 className="text-xl font-semibold text-slate-900">
          Opportunity not found
        </h2>

        <button
          type="button"
          className="rounded-xl bg-indigo-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-600"
          onClick={() => router.push("/search")}
        >
          Go Back
        </button>
      </div>
    );
  }

  // Parse "YYYY-MM-DD" as a local date so the stored day is
  // never shifted by the browser's timezone.
  const formatDate = (dateValue) => {
    if (!dateValue) return "";

    const match = String(dateValue).match(/^(\d{4})-(\d{2})-(\d{2})/);

    if (!match) {
      return new Date(dateValue).toLocaleDateString("en-US", {
        day: "numeric",
        month: "long",
        year: "numeric",
      });
    }

    const date = new Date(
      Number(match[1]),
      Number(match[2]) - 1,
      Number(match[3])
    );

    return date.toLocaleDateString("en-US", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  const formattedDate = formatDate(opportunity.date);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="sticky top-0 z-50 flex h-[60px] items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md">
        <button
          type="button"
          aria-label="Go back"
          className="flex size-9 items-center justify-center rounded-full text-slate-700 transition hover:bg-slate-100"
          onClick={() => router.back()}
        >
          <ArrowLeft size={21} />
        </button>

        <h1 className="text-base font-semibold text-slate-900">
          Opportunity
        </h1>

        <div className="size-9" />
      </header>

      {/* Banner */}
      {opportunity.banner && (
        <div className="w-full bg-slate-100">
          <img
            className="mx-auto block max-h-[360px] w-full object-cover sm:max-w-4xl"
            src={opportunity.banner}
            alt={opportunity.title}
          />
        </div>
      )}

      {/* Content */}
      <main className="mx-auto w-full max-w-[760px] px-4 py-6 pb-20 sm:px-6">
        <div className="flex flex-col gap-5">
          {/* Type */}
          <span className="self-start rounded-lg bg-indigo-50 px-3 py-1.5 text-xs font-semibold text-indigo-500">
            {opportunity.type}
          </span>

          {/* Title */}
          <h2 className="break-words text-2xl font-bold leading-tight text-slate-900 sm:text-3xl">
            {opportunity.title}
          </h2>

          {/* Metadata */}
          <div className="flex flex-wrap gap-x-5 gap-y-3">
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <CalendarDays
                size={17}
                className="shrink-0 text-slate-400"
              />
              <span>{formattedDate}</span>
            </div>

            {opportunity.location && (
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <MapPin
                  size={17}
                  className="shrink-0 text-slate-400"
                />
                <span>{opportunity.location}</span>
              </div>
            )}
          </div>

          {/* Description */}
          <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <h3 className="text-sm font-semibold text-slate-900">
              About this opportunity
            </h3>

            <p className="mt-3 whitespace-pre-wrap text-sm leading-7 text-slate-600">
              {opportunity.description}
            </p>
          </section>

          {/* Link */}
          {opportunity.link && (
            <a
              href={opportunity.link}
              target="_blank"
              rel="noreferrer"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-500 px-5 py-3 text-sm font-semibold text-white transition hover:bg-indigo-600 sm:w-fit"
            >
              Register / Learn More
              <ExternalLink size={17} />
            </a>
          )}
        </div>
      </main>
    </div>
  );
}