"use client";

import { useState } from "react";
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreHorizontal,
} from "lucide-react";

import LoginPrompt from "./LoginPrompt";
import { useAuth } from "@/context/AuthContext";

function PostCard({
  name,
  branch,
  year,
  time,
  content,
  likes,
  comments,
  image,
  avatar,
}) {
  const { isLoggedIn } = useAuth();

  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(likes);
  const [bookmarked, setBookmarked] = useState(false);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);

  const requireLogin = () => {
    if (!isLoggedIn) {
      setShowLoginPrompt(true);
      return true;
    }

    return false;
  };

  const handleLike = () => {
    if (requireLogin()) return;

    setLiked((previous) => !previous);

    setLikeCount((previous) =>
      liked ? previous - 1 : previous + 1
    );
  };

  const handleBookmark = () => {
    if (requireLogin()) return;

    setBookmarked((previous) => !previous);
  };

  const handleComment = () => {
    if (requireLogin()) return;

    console.log("Open comments");
  };

  const handleShare = () => {
    if (requireLogin()) return;

    console.log("Share post");
  };

  return (
    <>
      <article className="w-full overflow-hidden rounded-[14px] border border-slate-200 bg-white p-[14px] shadow-[0_2px_8px_rgba(15,23,42,0.04)] mt-[10px] mb-[18px] mx-3 md:ml-0 md:mr-0 max-md:ml-2 max-md:mr-2 max-md:rounded-[15px] max-[380px]:mx-2 max-[380px]:p-3 lg:my-[14px] lg:rounded-2xl lg:p-4">
        <div className="flex items-center justify-between">
          <div className="flex min-w-0 items-center gap-[11px]">
            {avatar ? (
              <img
                className="size-[42px] shrink-0 rounded-full object-cover"
                src={avatar}
                alt={name}
              />
            ) : (
              <div className="flex size-[42px] shrink-0 items-center justify-center rounded-full bg-indigo-50 text-sm font-bold text-indigo-500">
                {name?.charAt(0)?.toUpperCase() || "U"}
              </div>
            )}

            <div>
              <h3 className="font-semibold text-slate-900 text-sm">
                {name}
              </h3>
              <p className="mt-[3px] text-slate-500 text-[12px]">
                {branch} • {year} • {time}
              </p>
            </div>
          </div>

          <button className="flex items-center justify-center">
            <MoreHorizontal size={20} />
          </button>
        </div>

        <div className="mt-[14px] pb-1">
          <p className="text-slate-900 text-sm leading-[1.55] [overflow-wrap:anywhere]">
            {content}
          </p>
        </div>

        {image && (
          <img
            className="mt-3 block aspect-[16/10] w-full max-h-[600px] rounded-[14px] object-cover max-md:max-h-[500px] lg:max-h-[650px] lg:aspect-[4/5]"
            src={image}
            alt="Post"
          />
        )}

        <div className="mt-3 flex items-center justify-between border-t border-slate-200 pt-3">
          <div className="flex items-center gap-[18px]">
            <button
              className="flex items-center gap-1.5 p-[3px] text-slate-500 hover:text-slate-900 active:scale-90"
              onClick={handleLike}
            >
              <Heart
                size={20}
                fill={liked ? "currentColor" : "none"}
              />
              <span>{likeCount}</span>
            </button>

            <button
              className="flex items-center gap-1.5 p-[3px] text-slate-500 hover:text-slate-900 active:scale-90"
              onClick={handleComment}
            >
              <MessageCircle size={20} />
              <span>{comments}</span>
            </button>

            <button
              className="flex items-center gap-1.5 p-[3px] text-slate-500 hover:text-slate-900 active:scale-90"
              onClick={handleShare}
            >
              <Send size={20} />
            </button>
          </div>

          <button
            className="flex items-center gap-1.5 p-[3px] text-slate-500 hover:text-slate-900 active:scale-90"
            onClick={handleBookmark}
          >
            <Bookmark
              size={20}
              fill={bookmarked ? "currentColor" : "none"}
            />
          </button>
        </div>
      </article>

      <LoginPrompt
        isOpen={showLoginPrompt}
        onClose={() => setShowLoginPrompt(false)}
      />
    </>
  );
}

export default PostCard;