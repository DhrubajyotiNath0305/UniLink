const STORAGE_KEY = "unilink_opportunities";

export const getOpportunities = () => {
  if (typeof window === "undefined") {
    return [];
  }

  const savedOpportunities =
    localStorage.getItem(STORAGE_KEY);

  if (!savedOpportunities) {
    return [];
  }

  try {
    const parsed = JSON.parse(savedOpportunities);

    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const saveOpportunity = (opportunity) => {
  if (typeof window === "undefined") {
    return;
  }

  const existingOpportunities = getOpportunities();

  const updatedOpportunities = [
    opportunity,
    ...existingOpportunities,
  ];

  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(updatedOpportunities)
  );
};